export function quadIn(t) {
  return t * t;
}

export function quadOut(t) {
  return t * (2 - t);
}

export function quadInOut(t) {
  return ((t *= 2) <= 1 ? t * t : --t * (2 - t) + 1) / 2;
}
